import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import sodium from 'libsodium-wrappers';

type KeyPair = {
	publicKey: Uint8Array;
	privateKey: Uint8Array;
};

type TunnelState = 'disconnected' | 'connecting' | 'connected' | 'error';

type FileBundle = {
	encBlob?: Blob;
	encName?: string;
	stegoBlob?: Blob;
	stegoName?: string;
};

// Identity types/state
type IdentityRecord = {
	name: string;
	publicKey: Uint8Array;
	privateKey: Uint8Array;
};

type IdentitiesMap = Record<string, IdentityRecord>; // name -> IdentityRecord

function loadIdentities(): IdentitiesMap {
	try {
		const raw = localStorage.getItem('sis_identities');
		console.log('Raw localStorage data:', raw);
		if (!raw) {
			console.log('No identities found in localStorage');
			return {};
		}
		const parsed = JSON.parse(raw);
		console.log('Parsed identities:', parsed);
		// Convert hex strings back to Uint8Arrays
		const result: IdentitiesMap = {};
		for (const [name, identity] of Object.entries(parsed)) {
			if (identity && typeof identity === 'object' && 'publicKey' in identity && 'privateKey' in identity) {
				result[name] = {
					name,
					publicKey: hexToBytes(identity.publicKey as string),
					privateKey: hexToBytes(identity.privateKey as string)
				};
			}
		}
		console.log('Converted identities:', result);
		return result;
	} catch (error) {
		console.error('Error loading identities:', error);
		return {};
	}
}

function saveIdentities(ids: IdentitiesMap) {
	// Convert Uint8Arrays to hex strings for storage
	const serializable: Record<string, { publicKey: string; privateKey: string }> = {};
	for (const [name, identity] of Object.entries(ids)) {
		serializable[name] = {
			publicKey: bytesToHex(identity.publicKey),
			privateKey: bytesToHex(identity.privateKey)
		};
	}
	console.log('Saving identities to localStorage:', serializable);
	localStorage.setItem('sis_identities', JSON.stringify(serializable));
	console.log('Identities saved successfully');
}

async function loadQrLibrary(): Promise<any> {
	// Load qrcode.min.js from CDN and return window.QRCode
	if ((window as any).QRCode) return (window as any).QRCode;
	await new Promise<void>((resolve, reject) => {
		const s = document.createElement('script');
		s.src = 'https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js';
		s.async = true;
		s.onload = () => resolve();
		s.onerror = () => reject(new Error('Failed to load QR library'));
		document.head.appendChild(s);
	});
	return (window as any).QRCode;
}

async function drawQrToCanvas(text: string, canvas: HTMLCanvasElement) {
	const QR = await loadQrLibrary();
	await QR.toCanvas(canvas, text, { width: 256, margin: 2 });
}

async function detectQrFromImage(img: HTMLImageElement): Promise<string | null> {
	const supported = 'BarcodeDetector' in window && (window as any).BarcodeDetector;
	if (!supported) return null;
	try {
		const detector = new (window as any).BarcodeDetector({ formats: ['qr_code'] });
		const bitmap = await createImageBitmap(img);
		const results = await detector.detect(bitmap);
		return results?.[0]?.rawValue ?? null;
	} catch {
		return null;
	}
}

function useActivityLog() {
	const [entries, setEntries] = useState<string[]>([]);
	const log = useCallback((message: string) => {
		const ts = new Date().toLocaleTimeString();
		setEntries(prev => [`[${ts}] ${message}`, ...prev]);
	}, []);
	const clear = useCallback(() => setEntries([]), []);
	return { entries, log, clear };
}

function bytesToHex(bytes: Uint8Array): string {
	return Array.from(bytes)
		.map(b => b.toString(16).padStart(2, '0'))
		.join('');
}

function hexToBytes(hex: string): Uint8Array {
	const clean = hex.replace(/[^0-9a-fA-F]/g, '');
	const out = new Uint8Array(clean.length / 2);
	for (let i = 0; i < out.length; i++) out[i] = parseInt(clean.substr(i * 2, 2), 16);
	return out;
}

function concatUint8(...arrays: Uint8Array[]): Uint8Array {
	const total = arrays.reduce((n, a) => n + a.length, 0);
	const out = new Uint8Array(total);
	let offset = 0;
	for (const a of arrays) {
		out.set(a, offset);
		offset += a.length;
	}
	return out;
}

function u32ToBytesLE(n: number): Uint8Array {
	const b = new Uint8Array(4);
	const view = new DataView(b.buffer);
	view.setUint32(0, n >>> 0, true);
	return b;
}

function bytesToU32LE(b: Uint8Array): number {
	const view = new DataView(b.buffer, b.byteOffset, b.byteLength);
	return view.getUint32(0, true);
}

// Simple ECC using triple modular redundancy (repeat each bit 3x)
const ECC_REPEAT = 3;
function eccEncodeRepeat3(data: Uint8Array): Uint8Array {
	const bits = bytesToBits(data);
	const encBits: number[] = [];
	for (const bit of bits) for (let i = 0; i < ECC_REPEAT; i++) encBits.push(bit);
	return bitsToBytesArr(encBits);
}

function eccDecodeRepeat3(encoded: Uint8Array): Uint8Array {
	const bits = bytesToBits(encoded);
	const outBits: number[] = [];
	for (let i = 0; i < bits.length; i += ECC_REPEAT) {
		let ones = 0;
		for (let j = 0; j < ECC_REPEAT; j++) ones += bits[i + j] ? 1 : 0;
		outBits.push(ones >= 2 ? 1 : 0);
	}
	return bitsToBytesArr(outBits);
}

function bytesToBits(bytes: Uint8Array): number[] {
	const bits: number[] = [];
	for (let i = 0; i < bytes.length; i++) {
		for (let b = 7; b >= 0; b--) bits.push((bytes[i] >> b) & 1);
	}
	return bits;
}

function bitsToBytesArr(bits: number[]): Uint8Array {
	const len = Math.ceil(bits.length / 8);
	const out = new Uint8Array(len);
	for (let i = 0; i < len; i++) {
		let v = 0;
		for (let b = 0; b < 8; b++) {
			const bit = bits[i * 8 + b] ?? 0;
			v = (v << 1) | bit;
		}
		out[i] = v;
	}
	return out;
}

async function readFileAsArrayBuffer(file: File): Promise<ArrayBuffer> {
	return new Promise((resolve, reject) => {
		const r = new FileReader();
		r.onerror = () => reject(r.error);
		r.onload = () => resolve(r.result as ArrayBuffer);
		r.readAsArrayBuffer(file);
	});
}

async function readFileAsDataURL(file: File): Promise<string> {
	return new Promise((resolve, reject) => {
		const r = new FileReader();
		r.onerror = () => reject(r.error);
		r.onload = () => resolve(r.result as string);
		r.readAsDataURL(file);
	});
}

async function imageToCanvasData(url: string): Promise<{ canvas: HTMLCanvasElement; ctx: CanvasRenderingContext2D; imageData: ImageData; }>{
	return new Promise((resolve, reject) => {
		const img = new Image();
		img.onload = () => {
			const canvas = document.createElement('canvas');
			canvas.width = img.width;
			canvas.height = img.height;
			const ctx = canvas.getContext('2d');
			if (!ctx) return reject(new Error('Canvas 2D context not available'));
			ctx.drawImage(img, 0, 0);
			const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
			resolve({ canvas, ctx, imageData });
		};
		img.onerror = () => reject(new Error('Failed to load image'));
		img.src = url;
	});
}

function embedLSB(imageData: ImageData, payload: Uint8Array): ImageData {
	const MAGIC = new TextEncoder().encode('STEG');
	const lengthBytes = u32ToBytesLE(payload.length);
	const data = concatUint8(MAGIC, lengthBytes, payload);
	const pixels = imageData.data;
	const capacityBits = (pixels.length / 4) * 3; // 1 bit per RGB channel
	const neededBits = data.length * 8;
	if (neededBits > capacityBits) throw new Error('Cover image too small for payload');
	let dataIndex = 0;
	let bitIndex = 0;
	for (let i = 0; i < pixels.length && dataIndex < data.length; i += 4) {
		for (let c = 0; c < 3; c++) {
			const bit = (data[dataIndex] >> (7 - bitIndex)) & 1;
			pixels[i + c] = (pixels[i + c] & 0xFE) | bit;
			bitIndex++;
			if (bitIndex === 8) {
				bitIndex = 0;
				dataIndex++;
				if (dataIndex >= data.length) break;
			}
		}
	}
	return new ImageData(pixels, imageData.width, imageData.height);
}

function extractLSB(imageData: ImageData): Uint8Array {
	const pixels = imageData.data;
	const bits: number[] = [];
	for (let i = 0; i < pixels.length; i += 4) {
		for (let c = 0; c < 3; c++) bits.push(pixels[i + c] & 1);
	}
	function bitsToBytes(bitsArr: number[], byteCount: number, offsetBits: number): Uint8Array {
		const out = new Uint8Array(byteCount);
		for (let b = 0; b < byteCount; b++) {
			let v = 0;
			for (let i = 0; i < 8; i++) v = (v << 1) | bitsArr[offsetBits + b * 8 + i];
			out[b] = v;
		}
		return out;
	}
	const magic = new TextEncoder().encode('STEG');
	const magicBytes = bitsToBytes(bits, magic.length, 0);
	if (!magic.every((m, i) => m === magicBytes[i])) throw new Error('No payload found');
	const lengthBytes = bitsToBytes(bits, 4, magic.length * 8);
	const payloadLength = bytesToU32LE(lengthBytes);
	const payload = bitsToBytes(bits, payloadLength, (magic.length + 4) * 8);
	return payload;
}

export default function SecureImageShare() {
	const { entries, log, clear } = useActivityLog();
	const [sodiumReady, setSodiumReady] = useState(false);

	// Initialize sodium properly
	useEffect(() => {
		(async () => {
			log("⏳ Initializing sodium...");
			console.log("Starting sodium initialization...");
			try {
			await sodium.ready;
			console.log("Sodium ready, checking available functions...");
			console.log("crypto_box_keypair available:", typeof sodium.crypto_box_keypair);
			console.log("crypto_auth_hmacsha256 available:", typeof sodium.crypto_auth_hmacsha256);
			console.log("crypto_auth_hmacsha512 available:", typeof sodium.crypto_auth_hmacsha512);
			console.log("crypto_auth available:", typeof sodium.crypto_auth);
			console.log("crypto_aead_xchacha20poly1305_ietf_encrypt available:", typeof sodium.crypto_aead_xchacha20poly1305_ietf_encrypt);
			console.log("Available auth functions:", Object.keys(sodium).filter(key => key.includes('auth')));
			setSodiumReady(true);
			log("✅ Sodium fully initialized and ready.");
			} catch (error) {
				console.error("Sodium initialization error:", error);
				log(`❌ Sodium initialization failed: ${(error as Error).message}`);
			}
		})();
	}, [log]);

	const [senderKeyPair, setSenderKeyPair] = useState<KeyPair | null>(null);
	const [receiverKeyPair, setReceiverKeyPair] = useState<KeyPair | null>(null);

	// Identities state (name -> publicKeyHex) and selection
	const [identities, setIdentities] = useState<IdentitiesMap>({});
	const [selectedReceiver, setSelectedReceiver] = useState<string>('');
	const qrCanvasRef = useRef<HTMLCanvasElement | null>(null);
	const [importText, setImportText] = useState<string>('');

	useEffect(() => {
		setIdentities(loadIdentities());
	}, []);

	useEffect(() => {
		saveIdentities(identities);
		log('💾 Identities saved to localStorage: ' + Object.keys(identities).join(', '));
	}, [identities, log]);

	// Debug: Log when identities change
	useEffect(() => {
		log('🔄 Identities state updated: ' + Object.keys(identities).join(', '));
	}, [identities, log]);

	// Load keypair when identity is selected
	useEffect(() => {
		if (selectedReceiver && identities[selectedReceiver]) {
			const identity = identities[selectedReceiver];
			setReceiverKeyPair({ 
				publicKey: identity.publicKey, 
				privateKey: identity.privateKey 
			});
			log(`Loaded keypair for identity: ${selectedReceiver}`);
		}
	}, [selectedReceiver, identities, log]);

	const [confidentialFile, setConfidentialFile] = useState<File | null>(null);
	const [coverFile, setCoverFile] = useState<File | null>(null);
	const [stegoFile, setStegoFile] = useState<File | null>(null);
	const [encFile, setEncFile] = useState<File | null>(null);

	const [generated, setGenerated] = useState<FileBundle>({});

	// Multi-hop tunnel simulation
	type HopStatus = 'idle' | 'connecting' | 'connected' | 'failed';
	const hopNames = useRef<string[]>(['Alpha', 'Bravo', 'Charlie', 'Delta']);
	const [linkStatuses, setLinkStatuses] = useState<HopStatus[]>(['idle', 'idle', 'idle']); // between nodes i -> i+1
	const chanOutRefs = useRef<Array<RTCDataChannel | null>>([]); // channel from node i to i+1
	const nodePcRefs = useRef<Array<{ pcIn: RTCPeerConnection; pcOut: RTCPeerConnection }>>([]);

	const [receivedStego, setReceivedStego] = useState<Blob | null>(null);
	const [receivedEnc, setReceivedEnc] = useState<Blob | null>(null);

	const [deliverySummary, setDeliverySummary] = useState<{ encName?: string; stegoName?: string; encSize?: number; stegoSize?: number; hmacVerified: boolean | null; error?: string }>({ hmacVerified: null });

	// Routing selection and per-hop session keys
	const [routeLen, setRouteLen] = useState<number>(0); // 0=Direct, 1=2-hop uses 1 link? Here we map: 0=direct,1=2-hop uses first link,2=3-hop,3=4-hop
	const nodeKeypairsRef = useRef<Array<KeyPair>>([]);

	const utf8enc = new TextEncoder();
	const utf8dec = new TextDecoder();

	function buildHopOuter(capsule: Uint8Array): string {
		return JSON.stringify({ type: 'hop', capsule: btoa(String.fromCharCode(...capsule)) });
	}

	function parseHopOuter(data: string): Uint8Array | null {
		try {
			const obj = JSON.parse(data);
			if (obj?.type !== 'hop' || !obj?.capsule) return null;
			const bin = atob(obj.capsule as string);
			const bytes = new Uint8Array(bin.length);
			for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
			return bytes;
		} catch { return null; }
	}

	function encodeHopInner(next: number, total: number, innerPayload: Uint8Array): Uint8Array {
		const header = concatUint8(new TextEncoder().encode('HOP1'), new Uint8Array([next & 0xff]), new Uint8Array([total & 0xff]), u32ToBytesLE(innerPayload.length));
		return concatUint8(header, innerPayload);
	}

	function decodeHopInner(bytes: Uint8Array): { tag: string; next: number; total: number; payload: Uint8Array } {
		const tag = utf8dec.decode(bytes.slice(0, 4));
		const next = bytes[4];
		const total = bytes[5];
		const len = bytesToU32LE(bytes.slice(6, 10));
		const payload = bytes.slice(10, 10 + len);
		return { tag, next, total, payload };
	}

	function sealForNode(data: Uint8Array, nodeIndex: number): Uint8Array {
		const kp = nodeKeypairsRef.current[nodeIndex];
		if (!kp) throw new Error('Missing node key');
		return sodium.crypto_box_seal(data, kp.publicKey);
	}

	function openForNode(data: Uint8Array, nodeIndex: number): Uint8Array {
		const kp = nodeKeypairsRef.current[nodeIndex];
		if (!kp) throw new Error('Missing node key');
		return sodium.crypto_box_seal_open(data, kp.publicKey, kp.privateKey);
	}

	const [tunnelState, setTunnelState] = useState<TunnelState>('disconnected');

	const randomDelay = (minMs = 30, maxMs = 200) => new Promise(res => setTimeout(res, Math.floor(Math.random() * (maxMs - minMs + 1)) + minMs));

	// Remove this line since sodiumReady is already a boolean state

	const handleCreateIdentity = useCallback(async () => {
		log("🔄 Starting identity creation...");
		if (!sodiumReady) {
			log("⚠️ Sodium not ready yet — please wait a few seconds.");
			return;
		}

		try {
			log("🔑 Generating keypair...");
			await sodium.ready;
			const keypair = sodium.crypto_box_keypair();
			const name = prompt("Enter a name for this receiver:");
			if (!name) {
				log("❌ No name provided");
				return;
			}

			if (identities[name]) {
				alert('Identity name already exists');
				log('❌ Identity name already exists: ' + name);
				return;
			}

			const newIdentity: IdentityRecord = {
				name,
				publicKey: keypair.publicKey,
				privateKey: keypair.privateKey
			};

			log('💾 Storing identity...');
			setIdentities(prev => {
				const updated = { ...prev, [name]: newIdentity };
				log('📝 Updated identities: ' + Object.keys(updated).join(', '));
				return updated;
			});

			log('🎯 Setting selected receiver...');
			setSelectedReceiver(name);

			// Set receiverKeyPair locally so this device can decrypt for this identity
			setReceiverKeyPair({ publicKey: keypair.publicKey, privateKey: keypair.privateKey });
			log(`✅ Created new identity: ${name}`);
		} catch (err) {
			log("❌ Error creating identity: " + (err as Error).message);
			console.error(err);
		}
	}, [sodiumReady, identities, log]);

	const handleExportQR = useCallback(async () => {
		if (!selectedReceiver) return alert('Select an identity');
		const identity = identities[selectedReceiver];
		if (!identity) return alert('Missing identity');
		const pubHex = bytesToHex(identity.publicKey);
		const payload = JSON.stringify({ name: selectedReceiver, publicKeyHex: pubHex });
		if (!qrCanvasRef.current) return;
		await drawQrToCanvas(payload, qrCanvasRef.current);
		log('Rendered QR for public key export');
	}, [selectedReceiver, identities, log]);

	const handleImportQRText = useCallback(() => {
		try {
			const txt = importText.trim();
			if (!txt) return;
			let rec: { name: string; publicKeyHex: string } | null = null;
			if (txt.startsWith('{')) rec = JSON.parse(txt);
			else rec = { name: `imported-${Date.now()}`, publicKeyHex: txt };
			if (!rec?.publicKeyHex) throw new Error('Invalid payload');
			
			// Convert hex to Uint8Array for storage
			const publicKey = hexToBytes(rec.publicKeyHex);
			// For imported identities, we don't have the private key, so we'll store a placeholder
			// In a real implementation, you might want to handle this differently
			const importedIdentity: IdentityRecord = {
				name: rec.name,
				publicKey,
				privateKey: new Uint8Array(32) // Placeholder - imported identities can't decrypt
			};
			
			setIdentities(prev => ({ ...prev, [rec!.name]: importedIdentity }));
			setSelectedReceiver(rec!.name);
			log(`Imported identity '${rec!.name}'`);
		} catch (e) {
			alert(`Import failed: ${(e as Error).message}`);
		}
	}, [importText, log]);

	const handleImportQRImage = useCallback(async (file?: File) => {
		try {
			if (!file) return;
			const url = await readFileAsDataURL(file);
			const img = new Image();
			img.src = url;
			await new Promise<void>((res, rej) => { img.onload = () => res(); img.onerror = () => rej(new Error('Load error')); });
			const decoded = await detectQrFromImage(img);
			if (!decoded) return alert('No QR detected (try manual paste)');
			setImportText(decoded);
			log('QR decoded from image');
		} catch (e) {
			alert(`QR scan failed: ${(e as Error).message}`);
		}
	}, [log]);

	const handleGenerateKeypair = useCallback(async () => {
		if (!sodiumReady) {
			log('⚠️ Sodium not ready yet — please wait a few seconds.');
			return;
		}
		try {
			await sodium.ready;
			const sender = sodium.crypto_box_keypair();
			const receiver = sodium.crypto_box_keypair();
			setSenderKeyPair({ publicKey: sender.publicKey, privateKey: sender.privateKey });
			setReceiverKeyPair({ publicKey: receiver.publicKey, privateKey: receiver.privateKey });
			log('Generated sender and receiver keypairs');
		} catch (error) {
			log(`❌ Error generating keypairs: ${(error as Error).message}`);
		}
	}, [sodiumReady, log]);

	const handleEncryptAndEmbed = useCallback(async () => {
		try {
			if (!sodiumReady) throw new Error('Sodium not ready');
			const receiverIdentity = selectedReceiver ? identities[selectedReceiver] : undefined;
			if (!receiverIdentity && !receiverKeyPair) throw new Error('Receiver identity or keypair required');
			if (!confidentialFile) throw new Error('Select a confidential image');
			if (!coverFile) throw new Error('Select a cover image');
			log('Reading images...');
			const [secretBytes, coverUrl] = await Promise.all([
				readFileAsArrayBuffer(confidentialFile).then(b => new Uint8Array(b)),
				readFileAsDataURL(coverFile),
			]);
		await sodium.ready;
		console.log("Sodium ready in encryption, checking HMAC function...");
		console.log("crypto_auth_hmacsha256 available:", typeof sodium.crypto_auth_hmacsha256);
		console.log("crypto_auth available:", typeof sodium.crypto_auth);
		console.log("crypto_auth_hmacsha512 available:", typeof sodium.crypto_auth_hmacsha512);
		
		// Use the correct HMAC function
		let hmacFunction;
		if (typeof sodium.crypto_auth_hmacsha256 === 'function') {
			hmacFunction = sodium.crypto_auth_hmacsha256;
		} else if (typeof sodium.crypto_auth === 'function') {
			hmacFunction = sodium.crypto_auth;
		} else if (typeof sodium.crypto_auth_hmacsha512 === 'function') {
			hmacFunction = sodium.crypto_auth_hmacsha512;
		} else {
			throw new Error('No HMAC function available');
		}
		
		console.log("Using HMAC function:", hmacFunction.name || 'anonymous');
			const key = sodium.randombytes_buf(sodium.crypto_aead_xchacha20poly1305_ietf_KEYBYTES);
			const nonce = sodium.randombytes_buf(sodium.crypto_aead_xchacha20poly1305_ietf_NPUBBYTES);
			log('Encrypting confidential image...');
			const ciphertext = sodium.crypto_aead_xchacha20poly1305_ietf_encrypt(secretBytes, null, null, nonce, key);
			const recvPubKey = receiverIdentity ? receiverIdentity.publicKey : receiverKeyPair!.publicKey;
			const sealedKey = sodium.crypto_box_seal(key, recvPubKey);
		// HMAC over nonce||ciphertext using key-derived HMAC key
		const hmacKey = sodium.crypto_generichash(32, key);
		const dataForHmac = concatUint8(nonce, new Uint8Array(ciphertext));
		console.log("About to call HMAC function...");
		const hmac = hmacFunction(dataForHmac, hmacKey);
		log('Computed HMAC over nonce+ciphertext');
			const magic = new TextEncoder().encode('ENC1');
		const encPayload = concatUint8(magic, u32ToBytesLE(nonce.length), nonce, new Uint8Array(ciphertext));
		const encBlob = new Blob([encPayload as BlobPart], { type: 'application/octet-stream' });
			log(`Ciphertext size: ${encBlob.size} bytes; sealed key: ${sealedKey.length} bytes`);
			// Build inner stego payload before ECC: 'SISH' | ver(1) | eccRepeat(1) | hmacType(1) | sealedLen(u32) | hmacLen(u32) | sealedKey | hmac
			const innerHeader = concatUint8(
				new TextEncoder().encode('SISH'),
				new Uint8Array([1]), // version
				new Uint8Array([ECC_REPEAT]),
				new Uint8Array([1]), // hmac type 1 = HMAC-SHA256
				u32ToBytesLE(sealedKey.length),
				u32ToBytesLE(hmac.length),
			);
			const innerPayload = concatUint8(innerHeader, sealedKey, hmac);
			const eccPayload = eccEncodeRepeat3(innerPayload);
			log(`ECC encoded payload length: ${innerPayload.length} -> ${eccPayload.length} bytes`);
			log('Embedding ECC+HMAC stego payload via LSB...');
			const { canvas, ctx, imageData } = await imageToCanvasData(coverUrl);
			const stegoImageData = embedLSB(imageData, eccPayload);
			ctx.putImageData(stegoImageData, 0, 0);
			const stegoDataUrl = canvas.toDataURL('image/png');
			const stegoBlob = await (await fetch(stegoDataUrl)).blob();
			setGenerated({
				encBlob,
				encName: confidentialFile.name.replace(/\.[^.]+$/, '') + '.enc',
				stegoBlob,
				stegoName: coverFile.name.replace(/\.[^.]+$/, '') + '.stego.png',
			});
			log('Generated .enc and .stego.png artifacts');
		} catch (error) {
			log(`❌ Encryption error: ${(error as Error).message}`);
			console.error('Encryption error:', error);
			throw error;
		}
	}, [sodiumReady, identities, selectedReceiver, receiverKeyPair, confidentialFile, coverFile, log]);

	const handleExtractAndDecrypt = useCallback(async () => {
		if (!sodiumReady) throw new Error('Sodium not ready');
		if (!receiverKeyPair) throw new Error('Receiver keypair required');
		const stegoSource = stegoFile ?? (generated.stegoBlob ? new File([generated.stegoBlob], generated.stegoName || 'cover.stego.png') : null);
		const encSource = encFile ?? (generated.encBlob ? new File([generated.encBlob], generated.encName || 'secret.enc') : null);
		if (!stegoSource || !encSource) throw new Error('Provide stego image and .enc file');
		log('Decoding stego image...');
		const stegoUrl = await readFileAsDataURL(stegoSource);
		const { imageData } = await imageToCanvasData(stegoUrl);
		const eccPayload = extractLSB(imageData);
		log(`Extracted raw stego payload (${eccPayload.length} bytes)`);
		const innerPayload = eccDecodeRepeat3(eccPayload);
		log(`ECC decoded payload (${innerPayload.length} bytes)`);
		// Parse inner payload
		const dv = new DataView(innerPayload.buffer, innerPayload.byteOffset, innerPayload.byteLength);
		const tag = new TextDecoder().decode(innerPayload.slice(0, 4));
		if (tag !== 'SISH') throw new Error('Invalid stego inner header');
		const ver = innerPayload[4];
		const eccRep = innerPayload[5];
		const hmacType = innerPayload[6];
		if (ver !== 1) throw new Error('Unsupported stego version');
		if (eccRep !== ECC_REPEAT) log(`Warning: ECC repeat in payload (${eccRep}) differs from expected (${ECC_REPEAT})`);
		if (hmacType !== 1) throw new Error('Unsupported HMAC type');
		const sealedLen = dv.getUint32(7, true);
		const hmacLen = dv.getUint32(11, true);
		const sealedStart = 15;
		const sealedEnd = sealedStart + sealedLen;
		const hmacStart = sealedEnd;
		const hmacEnd = hmacStart + hmacLen;
		if (hmacEnd > innerPayload.length) throw new Error('Truncated stego inner payload');
		const sealedKey = innerPayload.slice(sealedStart, sealedEnd);
		const hmac = innerPayload.slice(hmacStart, hmacEnd);
		log(`Parsed inner payload: sealedKey=${sealedKey.length} bytes, hmac=${hmac.length} bytes`);
		await sodium.ready;
		console.log("Sodium ready in decryption, checking HMAC function...");
		console.log("crypto_auth_hmacsha256 available:", typeof sodium.crypto_auth_hmacsha256);
		console.log("crypto_auth available:", typeof sodium.crypto_auth);
		console.log("crypto_auth_hmacsha512 available:", typeof sodium.crypto_auth_hmacsha512);
		
		// Use the correct HMAC function
		let hmacFunction;
		if (typeof sodium.crypto_auth_hmacsha256 === 'function') {
			hmacFunction = sodium.crypto_auth_hmacsha256;
		} else if (typeof sodium.crypto_auth === 'function') {
			hmacFunction = sodium.crypto_auth;
		} else if (typeof sodium.crypto_auth_hmacsha512 === 'function') {
			hmacFunction = sodium.crypto_auth_hmacsha512;
		} else {
			throw new Error('No HMAC function available in decryption');
		}
		
		console.log("Using HMAC function in decryption:", hmacFunction.name || 'anonymous');
		const key = sodium.crypto_box_seal_open(sealedKey, receiverKeyPair.publicKey, receiverKeyPair.privateKey);
		log('Unsealed symmetric key');
		const encBytes = new Uint8Array(await readFileAsArrayBuffer(encSource));
		const magic = new TextEncoder().encode('ENC1');
		if (!magic.every((m, i) => m === encBytes[i])) throw new Error('Invalid .enc header');
		const nonceLen = bytesToU32LE(encBytes.slice(4, 8));
		const nonce = encBytes.slice(8, 8 + nonceLen);
		const ciphertext = encBytes.slice(8 + nonceLen);
		// Verify HMAC before decryption
		const hmacKey = sodium.crypto_generichash(32, key);
		const dataForHmac = concatUint8(nonce, ciphertext);
		console.log("About to call HMAC function in decryption...");
		const recomputed = hmacFunction(dataForHmac, hmacKey);
		const ok = sodium.memcmp(hmac, recomputed);
		if (!ok) {
			log('INTEGRITY WARNING: HMAC verification failed. Aborting decryption.');
			throw new Error('HMAC verification failed');
		}
		log('HMAC verified');
		log('Decrypting image...');
		const plaintext = sodium.crypto_aead_xchacha20poly1305_ietf_decrypt(null, ciphertext, null, nonce, key);
		const mimeGuess = 'application/octet-stream';
		const outBlob = new Blob([plaintext], { type: mimeGuess });
		const url = URL.createObjectURL(outBlob);
		const a = document.createElement('a');
		a.href = url;
		a.download = 'decrypted-image';
		a.click();
		URL.revokeObjectURL(url);
		log('Decryption complete; downloaded decrypted-image');
	}, [sodiumReady, receiverKeyPair, stegoFile, encFile, generated, log]);

	const handleConnectTunnel = useCallback(async () => {
		if (tunnelState === 'connected') return;
		setTunnelState('connecting');
		log('Establishing multi-hop VPN-like WebRTC tunnel...');
		const names = hopNames.current;
		const hopCountMax = names.length - 1;
		const activeLinks = Math.min(routeLen + 1, hopCountMax); // 0->1 direct mapping: 0=>1 link, 1=>2 links...
		setLinkStatuses(Array(hopCountMax).fill('idle').map((_, i) => i < activeLinks ? 'connecting' : 'idle'));
		chanOutRefs.current = [];
		nodePcRefs.current = [];
		nodeKeypairsRef.current = [];
		try {
			// Generate session keypairs for each node involved
			await sodium.ready;
			for (let i = 0; i < activeLinks + 1; i++) {
				const kp = sodium.crypto_box_keypair();
				nodeKeypairsRef.current[i] = { publicKey: kp.publicKey, privateKey: kp.privateKey };
			}
			for (let i = 0; i < activeLinks; i++) {
				const a = new RTCPeerConnection();
				const b = new RTCPeerConnection();
				nodePcRefs.current.push({ pcIn: a, pcOut: b });
				const chanOut = a.createDataChannel(`hop-${i}`, { ordered: true });
				chanOutRefs.current[i] = chanOut;
				chanOut.onopen = () => {
					setLinkStatuses(prev => prev.map((s, idx) => idx === i ? 'connected' : s));
					log(`DataChannel hop-${i} open (${names[i]} → ${names[i+1]})`);
				};
				chanOut.onerror = (ev) => {
					setLinkStatuses(prev => prev.map((s, idx) => idx === i ? 'failed' : s));
					log(`DataChannel hop-${i} error: ${String((ev as any).message || ev)}`);
				};
				a.onconnectionstatechange = () => {
					log(`PC a hop-${i} state: ${a.connectionState}`);
					if (a.connectionState === 'failed' || a.connectionState === 'disconnected' || a.connectionState === 'closed') {
						setLinkStatuses(prev => prev.map((s, idx) => idx === i ? 'failed' : s));
					}
				};
				b.onconnectionstatechange = () => {
					log(`PC b hop-${i} state: ${b.connectionState}`);
					if (b.connectionState === 'failed' || b.connectionState === 'disconnected' || b.connectionState === 'closed') {
						setLinkStatuses(prev => prev.map((s, idx) => idx === i ? 'failed' : s));
					}
				};
				b.ondatachannel = (ev) => {
					const recvChan = ev.channel;
					recvChan.onopen = () => log(`Receiver channel hop-${i} open (${names[i]} → ${names[i+1]})`);
					recvChan.onmessage = async (mev) => {
						await randomDelay();
						// Check if it's a hop capsule
						const maybeCapsule = parseHopOuter(mev.data);
						if (maybeCapsule) {
							// Open for this node, then seal for next node if any
							let inner = openForNode(maybeCapsule, i); // node i receives
							const { tag, next, total, payload } = decodeHopInner(inner);
							if (tag !== 'HOP1') return;
							if (i + 1 < activeLinks) {
								const nextInner = encodeHopInner(i + 1, total, payload);
								const sealedNext = sealForNode(nextInner, i + 1);
								const out = buildHopOuter(sealedNext);
								const nextChan = chanOutRefs.current[i + 1];
								if (nextChan?.readyState === 'open') nextChan.send(out);
								log(`Hop capsule rewrapped ${names[i]} -> ${names[i+1]}`);
							} else {
								// Last hop: deliver original file JSON message to receiver
								const finalMsg = utf8dec.decode(payload);
								const { type, name, payload: base64 } = JSON.parse(finalMsg) as { type: 'file'; name: string; payload: string };
								const blob = b64ToBlob(base64, name.endsWith('.png') ? 'image/png' : 'application/octet-stream');
								if (name.endsWith('.stego.png')) { setReceivedStego(blob); setDeliverySummary(prev => ({ ...prev, stegoName: name, stegoSize: blob.size })); }
								if (name.endsWith('.enc')) { setReceivedEnc(blob); setDeliverySummary(prev => ({ ...prev, encName: name, encSize: blob.size })); }
								log(`Final delivery at ${names[i+1]}: ${name} (${blob.size} bytes)`);
							}
							return;
						}
						// Otherwise plain file JSON (legacy direct path)
						if (i + 1 < activeLinks) {
							const next = chanOutRefs.current[i + 1];
							if (next?.readyState === 'open') next.send(mev.data);
							log(`Relayed message ${names[i]} -> ${names[i+1]}`);
						} else {
							const { type, name, payload } = JSON.parse(mev.data) as { type: 'file'; name: string; payload: string };
							const blob = b64ToBlob(payload, name.endsWith('.png') ? 'image/png' : 'application/octet-stream');
							if (name.endsWith('.stego.png')) { setReceivedStego(blob); setDeliverySummary(prev => ({ ...prev, stegoName: name, stegoSize: blob.size })); }
							if (name.endsWith('.enc')) { setReceivedEnc(blob); setDeliverySummary(prev => ({ ...prev, encName: name, encSize: blob.size })); }
							log(`Final delivery at ${names[i+1]}: ${name} (${blob.size} bytes)`);
						}
					};
				};
				// ICE link
				a.onicecandidate = e => e.candidate && b.addIceCandidate(e.candidate);
				b.onicecandidate = e => e.candidate && a.addIceCandidate(e.candidate);
				const offer = await a.createOffer();
				await a.setLocalDescription(offer);
				await b.setRemoteDescription(offer);
				const answer = await b.createAnswer();
				await b.setLocalDescription(answer);
				await a.setRemoteDescription(answer);
				setLinkStatuses(prev => prev.map((s, idx) => idx === i ? 'connected' : s));
				log(`Link ${names[i]} → ${names[i+1]} connected`);
			}
			setTunnelState('connected');
			log(`Multi-hop tunnel connected. Active route: ${activeLinks} link(s).`);
		} catch (e) {
			setTunnelState('error');
			setLinkStatuses(prev => prev.map((_, idx) => prev[idx] === 'connected' ? 'connected' : 'failed'));
			log(`Tunnel error: ${(e as Error).message}`);
		}
	}, [tunnelState, routeLen, log]);

	const b64ToBlob = (b64: string, type: string) => {
		const bin = atob(b64);
		const bytes = new Uint8Array(bin.length);
		for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
		return new Blob([bytes], { type });
	};

	const blobToB64 = async (blob: Blob): Promise<string> => {
		const ab = await blob.arrayBuffer();
		let s = '';
		const bytes = new Uint8Array(ab);
		for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
		return btoa(s);
	};

	const handleSendOverTunnel = useCallback(async () => {
		if (tunnelState !== 'connected') throw new Error('Tunnel not connected');
		if (!generated.encBlob || !generated.stegoBlob) throw new Error('No generated artifacts to send');
		const firstHop = chanOutRefs.current[0];
		if (!firstHop || firstHop.readyState !== 'open') throw new Error('First hop unavailable');
		const names = hopNames.current;
		const hopCountMax = names.length - 1;
		const activeLinks = Math.min(routeLen + 1, hopCountMax);
		log(`Transferring files over route with ${activeLinks} link(s)...`);
		const encB64 = await blobToB64(generated.encBlob);
		const stegoB64 = await blobToB64(generated.stegoBlob);
		const msgs = [
			JSON.stringify({ type: 'file', name: generated.encName || 'secret.enc', payload: encB64 }),
			JSON.stringify({ type: 'file', name: generated.stegoName || 'cover.stego.png', payload: stegoB64 }),
		];
		for (const m of msgs) {
			let cargo: Uint8Array = new Uint8Array(utf8enc.encode(m));
			if (activeLinks > 0) {
				// Build nested capsules from first hop to last hop
				for (let i = 0; i < activeLinks; i++) {
					const inner = encodeHopInner(i, activeLinks, cargo);
					const sealed = sealForNode(inner, i);
					cargo = sealed;
				}
				firstHop.send(buildHopOuter(cargo));
				log('Injected sealed hop capsule into first hop');
			} else {
				firstHop.send(m);
				log('Injected plain message into first hop');
			}
		}
	}, [tunnelState, generated, routeLen, log]);

	const handleSelfTest = useCallback(async () => {
		if (!sodiumReady) throw new Error('Sodium not ready');
		log('Running self-test...');
		await sodium.ready;
		const recv = sodium.crypto_box_keypair();
		setReceiverKeyPair({ publicKey: recv.publicKey, privateKey: recv.privateKey });
		const secretCanvas = document.createElement('canvas');
		secretCanvas.width = 64; secretCanvas.height = 64;
		const sctx = secretCanvas.getContext('2d');
		if (!sctx) throw new Error('No canvas context');
		for (let y = 0; y < secretCanvas.height; y++) {
			for (let x = 0; x < secretCanvas.width; x++) {
				const v = (x ^ y) & 0xFF;
				sctx.fillStyle = `rgb(${v}, ${255 - v}, ${v})`;
				sctx.fillRect(x, y, 1, 1);
			}
		}
		const secretBlob = await (await fetch(secretCanvas.toDataURL('image/png'))).blob();
		const coverCanvas = document.createElement('canvas');
		coverCanvas.width = 128; coverCanvas.height = 128;
		const cctx = coverCanvas.getContext('2d');
		if (!cctx) throw new Error('No canvas context');
		cctx.fillStyle = '#88a';
		cctx.fillRect(0, 0, coverCanvas.width, coverCanvas.height);
		const coverBlob = await (await fetch(coverCanvas.toDataURL('image/png'))).blob();
		setConfidentialFile(new File([secretBlob], 'secret.png'));
		setCoverFile(new File([coverBlob], 'cover.png'));
		await handleEncryptAndEmbed();
		log('Self-test: encryption and embedding complete');
		await handleConnectTunnel();
		const maxWaitMs = 2000;
		await new Promise(r => setTimeout(r, maxWaitMs));
		await handleSendOverTunnel();
		log('Self-test: transfer sent');
		if (receivedEnc && receivedStego) {
			setEncFile(new File([receivedEnc], 'received.enc'));
			setStegoFile(new File([receivedStego], 'received.stego.png'));
		}
		await new Promise(r => setTimeout(r, 500));
		await handleExtractAndDecrypt();
		log('Self-test PASSED');
	}, [sodiumReady, handleEncryptAndEmbed, handleConnectTunnel, handleSendOverTunnel, handleExtractAndDecrypt, receivedEnc, receivedStego, log]);

	const downloadBlob = useCallback((blob: Blob, name: string) => {
		const url = URL.createObjectURL(blob);
		const a = document.createElement('a');
		a.href = url;
		a.download = name;
		a.click();
		URL.revokeObjectURL(url);
	}, []);

	const senderPubHex = useMemo(() => senderKeyPair ? bytesToHex(senderKeyPair.publicKey) : '', [senderKeyPair]);
	const receiverPubHex = useMemo(() => receiverKeyPair ? bytesToHex(receiverKeyPair.publicKey) : '', [receiverKeyPair]);

	useEffect(() => {
		(async () => {
			if (receivedEnc && receivedStego) {
				// Auto-prepare files and trigger decrypt
				setEncFile(new File([receivedEnc], deliverySummary.encName || 'received.enc'));
				setStegoFile(new File([receivedStego], deliverySummary.stegoName || 'received.stego.png'));
				try {
					await handleExtractAndDecrypt();
					setDeliverySummary(prev => ({ ...prev, hmacVerified: true, error: undefined }));
					log('Auto-receive: ✅ HMAC verified and decryption complete');
				} catch (e) {
					setDeliverySummary(prev => ({ ...prev, hmacVerified: false, error: (e as Error).message }));
					log('Auto-receive: ❌ HMAC failed or decryption error');
				}
			}
		})();
	}, [receivedEnc, receivedStego, handleExtractAndDecrypt, deliverySummary.encName, deliverySummary.stegoName, log]);

	return (
		<div className="min-h-screen bg-slate-950 text-slate-100 p-4 md:p-6">
			<div className="max-w-7xl mx-auto space-y-4">
				<div className="flex items-center justify-between">
					<h2 className="text-2xl md:text-3xl font-semibold tracking-tight">Secure Military-Style Image Transport</h2>
					<div className="text-sm md:text-base">{tunnelState === 'connected' ? '🟢 Connected' : '🔴 Disconnected'}</div>
				</div>
				<div className="grid grid-cols-1 md:grid-cols-4 gap-4 md:gap-6">
					{/* Sidebar */}
					<div className="md:col-span-1 space-y-4">
						<div className="rounded-xl border border-slate-800 bg-slate-900/80 shadow-lg p-4 space-y-3">
							<div className="flex items-center justify-between">
								<div className="font-medium">Receiver Identities</div>
								<button className="px-3 py-2 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-100 text-sm disabled:opacity-50 disabled:pointer-events-none" onClick={handleCreateIdentity} disabled={!sodiumReady}>New</button>
							</div>
							<select className="block w-full text-sm text-slate-200 bg-slate-950 border border-slate-800 rounded-md p-2" value={selectedReceiver} onChange={e => setSelectedReceiver(e.target.value)}>
								<option value="">Select receiver…</option>
								{Object.entries(identities).map(([name, identity]) => (
									<option key={name} value={name}>{name}</option>
								))}
							</select>
							<div className="grid grid-cols-2 gap-2">
								<select className="block w-full text-sm text-slate-200 bg-slate-950 border border-slate-800 rounded-md p-2" value={routeLen} onChange={e => { const v = Number(e.target.value); setRouteLen(v); log(`Route selected: ${v===0?'Direct':v===1?'2-hop':v===2?'3-hop':'4-hop'}`); }}>
									<option value={0}>Route: Direct</option>
									<option value={1}>Route: 2-hop</option>
									<option value={2}>Route: 3-hop</option>
									<option value={3}>Route: 4-hop</option>
								</select>
								<button className="px-3 py-2 rounded-md border border-slate-700 hover:border-slate-500 text-slate-100 text-sm disabled:opacity-50 disabled:pointer-events-none" onClick={() => handleExportQR().catch(e => log((e as Error).message))} disabled={!selectedReceiver}>Export QR</button>
							</div>
							<input type="text" className="block w-full text-sm text-slate-200 bg-slate-950 border border-slate-800 rounded-md p-2" placeholder="Paste public key or JSON {name,publicKeyHex}" value={importText} onChange={e => setImportText(e.target.value)} />
							<div className="flex items-center gap-2">
								<input type="file" accept="image/*" className="block w-full text-sm text-slate-200 bg-slate-950 border border-slate-800 rounded-md p-2" onChange={e => handleImportQRImage(e.target.files?.[0] || undefined)} />
								<button className="px-3 py-2 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-100 text-sm disabled:opacity-50 disabled:pointer-events-none" onClick={handleImportQRText}>Import</button>
							</div>
							<canvas ref={qrCanvasRef} className="w-full h-auto rounded-lg bg-slate-950 border border-slate-800" />
						</div>

						<div className={`rounded-xl border p-4 shadow-lg ${tunnelState === 'connected' ? 'border-emerald-600/60 bg-emerald-950/30' : 'border-slate-800 bg-slate-900/80'}`}>
							<div className="flex items-center justify-between">
								<div className="font-medium">Tunnel: {tunnelState}</div>
								<button className="px-3 py-2 rounded-md bg-emerald-700 hover:bg-emerald-600 text-white text-sm disabled:opacity-50 disabled:pointer-events-none" onClick={() => handleConnectTunnel().catch(e => log((e as Error).message))} disabled={tunnelState === 'connected'}>Connect</button>
							</div>
							<div className="mt-2 text-xs text-slate-400">Local multi-hop WebRTC tunnel</div>
						</div>

						<div className="rounded-xl border border-slate-800 bg-slate-900/80 shadow-lg p-4 space-y-3">
							<div className="font-medium mb-1">Network Map</div>
							<div className="space-y-2">
								{hopNames.current.map((name, idx) => (
									<div key={name} className="flex items-center gap-2">
										<div className="px-2 py-1 rounded bg-slate-800/80 shadow">{name}</div>
										{idx < hopNames.current.length - 1 && (
											<div className="flex items-center gap-2">
												<span className="text-slate-500">→</span>
												<span className="text-xs">
													{linkStatuses[idx] === 'connected' ? '🟢' : linkStatuses[idx] === 'connecting' ? '🟡' : linkStatuses[idx] === 'failed' ? '🔴' : '⚪'}
												</span>
											</div>
										)}
									</div>
								))}
							</div>
						</div>
					</div>

					{/* Main panel */}
					<div className="md:col-span-3 space-y-4">
						<div className="rounded-xl border border-slate-800 bg-slate-900/80 shadow-lg p-4 space-y-4">
							<div className="flex gap-2 flex-wrap">
								<button className="px-3 py-2 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-100 text-sm disabled:opacity-50 disabled:pointer-events-none" onClick={handleGenerateKeypair} disabled={!sodiumReady}>Generate keypair</button>
								<button className="px-3 py-2 rounded-md bg-emerald-600 hover:bg-emerald-500 text-white text-sm disabled:opacity-50 disabled:pointer-events-none" onClick={() => handleEncryptAndEmbed().catch(e => log((e as Error).message))} disabled={!sodiumReady}>Encrypt & Embed</button>
								<button className="px-3 py-2 rounded-md bg-indigo-600 hover:bg-indigo-500 text-white text-sm disabled:opacity-50 disabled:pointer-events-none" onClick={() => handleExtractAndDecrypt().catch(e => log((e as Error).message))} disabled={!sodiumReady}>Extract & Decrypt</button>
								<button className="px-3 py-2 rounded-md bg-emerald-700 hover:bg-emerald-600 text-white text-sm disabled:opacity-50 disabled:pointer-events-none" onClick={() => handleSelfTest().catch(e => log((e as Error).message))} disabled={!sodiumReady}>Run Self-Test</button>
								<button className="px-3 py-2 rounded-md border border-slate-700 hover:border-slate-500 text-slate-100 text-sm disabled:opacity-50 disabled:pointer-events-none" onClick={() => handleSendOverTunnel().catch(e => log((e as Error).message))} disabled={tunnelState !== 'connected' || !generated.encBlob || !generated.stegoBlob}>Send artifacts</button>
							</div>

							<div className="grid md:grid-cols-2 gap-4">
								<div className="space-y-2">
									<label className="block text-sm text-slate-400">Confidential image</label>
									<input type="file" accept="image/*" className="block w-full text-sm text-slate-200 bg-slate-950 border border-slate-800 rounded-md p-2" onChange={e => setConfidentialFile(e.target.files?.[0] || null)} />
								</div>
								<div className="space-y-2">
									<label className="block text-sm text-slate-400">Cover image</label>
									<input type="file" accept="image/*" className="block w-full text-sm text-slate-200 bg-slate-950 border border-slate-800 rounded-md p-2" onChange={e => setCoverFile(e.target.files?.[0] || null)} />
								</div>
							</div>

							<div className="grid md:grid-cols-2 gap-4">
								<div className="space-y-2">
									<label className="block text-sm text-slate-400">Stego image (.stego.png)</label>
									<input type="file" accept="image/png" className="block w-full text-sm text-slate-200 bg-slate-950 border border-slate-800 rounded-md p-2" onChange={e => setStegoFile(e.target.files?.[0] || null)} />
									{generated.stegoBlob && (
										<div className="flex gap-2">
											<button className="px-3 py-2 rounded-md border border-slate-700 hover:border-slate-500 text-slate-100 text-sm disabled:opacity-50 disabled:pointer-events-none" onClick={() => downloadBlob(generated.stegoBlob!, generated.stegoName || 'cover.stego.png')}>Download stego</button>
										</div>
									)}
								</div>
								<div className="space-y-2">
									<label className="block text-sm text-slate-400">Encrypted file (.enc)</label>
									<input type="file" accept=".enc,application/octet-stream" className="block w-full text-sm text-slate-200 bg-slate-950 border border-slate-800 rounded-md p-2" onChange={e => setEncFile(e.target.files?.[0] || null)} />
									{generated.encBlob && (
										<div className="flex gap-2">
											<button className="px-3 py-2 rounded-md border border-slate-700 hover:border-slate-500 text-slate-100 text-sm disabled:opacity-50 disabled:pointer-events-none" onClick={() => downloadBlob(generated.encBlob!, generated.encName || 'secret.enc')}>Download .enc</button>
										</div>
									)}
								</div>
							</div>

							<div className="rounded-xl border border-slate-800 bg-slate-900/80 shadow-lg p-4">
								<div className="flex items-center justify-between mb-2">
									<div className="font-medium">Delivery Summary</div>
									<button className="px-3 py-2 rounded-md border border-slate-700 hover:border-slate-500 text-slate-100 text-sm disabled:opacity-50 disabled:pointer-events-none" onClick={() => setDeliverySummary({ hmacVerified: null })}>Reset</button>
								</div>
								<div className="text-sm grid md:grid-cols-2 gap-3">
									<div>
										<div className="text-slate-400">Stego</div>
										<div className="text-xs break-all" style={{fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace'}}>{deliverySummary.stegoName || '—'} {deliverySummary.stegoSize ? `(${deliverySummary.stegoSize} bytes)` : ''}</div>
									</div>
									<div>
										<div className="text-slate-400">Encrypted</div>
										<div className="text-xs break-all" style={{fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace'}}>{deliverySummary.encName || '—'} {deliverySummary.encSize ? `(${deliverySummary.encSize} bytes)` : ''}</div>
									</div>
									<div className="md:col-span-2">
										<div className="text-slate-400">Integrity</div>
										<div>{deliverySummary.hmacVerified === null ? '—' : deliverySummary.hmacVerified ? '✅ HMAC verified' : `❌ Failed${deliverySummary.error ? `: ${deliverySummary.error}` : ''}`}</div>
									</div>
								</div>
							</div>

							<div className="rounded-xl border border-slate-800 bg-slate-900/80 shadow-lg p-4">
								<div className="flex items-center justify-between mb-2">
									<div className="font-medium">Activity Log</div>
									<button className="px-3 py-2 rounded-md border border-slate-700 hover:border-slate-500 text-slate-100 text-sm disabled:opacity-50 disabled:pointer-events-none" onClick={clear}>Clear</button>
								</div>
								<div className="h-64 overflow-auto text-xs space-y-1 pr-2" style={{fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace'}}>
									{entries.map((e, idx) => (
										<div key={idx} className="text-slate-300">{e}</div>
									))}
								</div>
							</div>
						</div>
					</div>
				</div>
				<div className="text-xs text-slate-500">Client-side only. Identities stored locally. Uses QR for key exchange.</div>
			</div>

		</div>
	);
}